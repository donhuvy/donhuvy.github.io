package com.example.demo.controller;

import com.example.demo.model.Student;
import com.example.demo.repo.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
public class StudentController {

    @Autowired
    StudentRepository studentRepository;

    /**
     * GET http://localhost:8080/students
     *
     * @return
     */
    @GetMapping("/students")
    public List<Student> all() {
        Student student = new Student(
                "CH270141", "Do Nhu Vy", Student.Gender.MALE, 9);
        studentRepository.save(student);

        List<Student> actualList = new ArrayList<Student>();
        studentRepository.findAll().forEach(actualList::add);
        return actualList;
    }

}
